import edu.princeton.cs.algs4.Digraph;
import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.DirectedCycle;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class WordNet {

    private final TreeMap<String, List<Integer>> treeMap;
    private final SAP sap;
    private final String synsets;
    private final String hypernyms;
    private Digraph g;

    // constructor takes the name of the two input files
    public WordNet(String synsets, String hypernyms){
        if(synsets==null || hypernyms==null) throw new IllegalArgumentException();
        this.synsets = synsets;
        this.hypernyms = hypernyms;
        treeMap = new TreeMap<>();
        constructSynsets();
        constructHypernyms();
        this.sap = new SAP(g);
        DirectedCycle cycle = new DirectedCycle(g);
        if(cycle.hasCycle()) throw  new IllegalArgumentException();
    }

    private void constructSynsets() {
        String[] allLines = synsets.split("\n");
        this.g = new Digraph(allLines.length);
        for (String line : allLines) {
            if(line.isEmpty()) continue;
            String[] values = line.split(",");
            if(values.length > 1) {
                String[] synSets = values[1].split(" ");
                for (String synSet : synSets) {
                    treeMap.put(synSet, Collections.singletonList(Integer.parseInt(values[0])));
                }
            }
        }
    }

    private void constructHypernyms(){
        String[] allLines = hypernyms.split("\n");
        for (String line : allLines) {
            String[] values = line.split(",");
            if(values.length == 1) continue;
            for (int j = 1; j < values.length; j++) {
                g.addEdge(Integer.parseInt(values[0].trim()), Integer.parseInt(values[j].trim()));
            }
        }
    }

    // returns all WordNet nouns
    public Iterable<String> nouns(){
        return treeMap.keySet();
    }

    // is the word a WordNet noun?
    public boolean isNoun(String word){
        if(word == null) throw new IllegalArgumentException();
        for (String value :
                treeMap.keySet()) {
            if(value.equals(word)) return true;
        }
        return false;
    }

    // distance between nounA and nounB (defined below)
    public int distance(String nounA, String nounB){
        if(nounA == null || nounB == null) throw new IllegalArgumentException();
        return sap.length(treeMap.get(nounA),treeMap.get(nounB));
    }

    // a synset (second field of synsets.txt) that is the common ancestor of nounA and nounB
    // in a shortest ancestral path (defined below)

    public String sap(String nounA, String nounB){
        if(nounA == null || nounB == null) throw new IllegalArgumentException();
        int ancestorKey = sap.ancestor(treeMap.get(nounA),treeMap.get(nounB));
        for (Map.Entry<String,List<Integer>> values:
                treeMap.entrySet()) {
            if(values.getValue().contains(ancestorKey)){
                return values.getKey();
            }
        }
        return null;
    }
    // do unit testing of this class
    public static void main(String[] args){
        In hypernym = new In(args[0]);
        In synset = new In(args[1]);
        String hypernyms = hypernym.readAll();
        String synsets = synset.readAll();
        WordNet wordNet = new WordNet(synsets,hypernyms);
    }
}
